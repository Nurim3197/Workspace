$().ready(function(){
	
	var email = $(".member-menu").data("email");
	var boardId = $(".grid-view-board").data("board-id");
	
	console.log("로그인 이메일 : " + email);
	console.log("조회중인 게시글 번호 : " + boardId)
	
	loadReplies(boardId);
	
	$("#btn-save-reply").on("click", function () {
		createReplies(boardId);
	});
	
});


function loadReplies(boardId){
	
	var template = $("#reply-template").html();
	
	// $(template)인 이유는 위에서 받는게 .html가 붙어있어서 순수 html DOM이니까 그럼
	$(".reply-items").append( $(template) );
}

function createReplies(boardId){
	
	$(".write-reply").find("div.error").remove();
	
	$.post(`/board/reply/${boardId}`,
			{
				content:$(".txt-reply").val()
			}, function(createResult) {
				/*
				 * { "result" : true }
				*/
				console.log(createResult);
				
				// result의 값이 true라면
				// 댓글의 목록을 갱신한다.
				if(createResult.result){
					loadReplies(boardId);
				}
				else {
					// 에러가 존재하는 케이스
					// 키가 무엇인지 모른다)
					
					// key 변수에 createResult에 있는 키의 값이 반복 할당한다.
					var errorDiv = $("<div class='error'></div>");
					var errorUl = $("<ul></ul>");
					errorDiv.append(errorUl);
					
					// JSON (Object Literal)을 반복
					for(var key in createResult){
						// createResult[key]를 반복.
						for(var i in createResult[key]){
							var errorLi = $("<li></li>");
							errorLi.text(createResult[key][i]);
							errorUl.append(errorLi);
						}
						
					}
					$(".txt-reply").before(errorDiv);
				}
			});
}

function modifyReply(replyId){
	
}

function deleteReply(replyId){
	
}

function recommendReply(replyId){
	
}