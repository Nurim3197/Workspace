package com.ktdsuniversity.edu.hello_spring.bbs.vo;

import java.util.List;

public class ReplyListVO {
	
	
	/**
	 * 댓글 총 갯수
	 */
	private int ReplyCnt;
	
	/**
	 * 댓글 리스트
	 */
	private List<ReplyVO> ReplyList;

	
	public int getReplyCnt() {
		return ReplyCnt;
	}

	public void setReplyCnt(int replyCnt) {
		ReplyCnt = replyCnt;
	}

	public List<ReplyVO> getReplyList() {
		return ReplyList;
	}

	public void setReplyList(List<ReplyVO> replyList) {
		ReplyList = replyList;
	}
	
	
}
