package com.ktdsuniversity.edu.hello_spring.bbs.service;

import com.ktdsuniversity.edu.hello_spring.bbs.vo.ModifyReplyVO;
import com.ktdsuniversity.edu.hello_spring.bbs.vo.ReplyListVO;
import com.ktdsuniversity.edu.hello_spring.bbs.vo.WriteReplyVO;

public interface ReplyService {
	
	/**
	 * 게시글의 모든 댓글을 조회한다.
	 * @param boardId 조회할 게시글의 번호
	 * @return 게시글에 등록된 모든 댓글 목록
	 */
	public ReplyListVO getAllReplies(int boardId);
	
	
	/**
	 * 게시글에 댓글을 등록한다.
	 * @param replyVO 등록할 댓글의 정보
	 * @return 댓글을 등록한 개수
	 */
	public boolean createNewReply(WriteReplyVO writeReplyVO);
	
	/**
	 * 댓글 하나를 삭제한다.
	 * @param replyId 삭제할 댓글의 번호
	 * @param email 삭제를 요청한 사용자의 이메일
	 * @return 댓글 삭제 성공 여부
	 */
	public boolean deleteOneReply(int replyId, String email);
	
	
	/**
	 * 댓글 내용을 수정한다.
	 * @param replyVO 수정할 댓글의 정보
	 * @return 댓글 수정 성공 여부
	 */
	public boolean modifyOneReply(ModifyReplyVO modifyReplyVO);
	
	/**
	 * 댓글의 추천수를 1 증가시킨다.
	 * @param replyId 추천수를 1 증가시킬 댓글 번호
	 * @param email 추천수 증가를 요청한 사용자의 이메일
	 * @return 댓글 추천 성공 여부
	 */
	public boolean recommendOneReply(int replyId, String email);
	
}
