package com.ktdsuniversity.edu.hello_spring.common.utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.validation.BindingResult;

public final class ErrorMapUtil {

	// 동시성 문제가 발생할 가능성이 매우 높다.
	// Validation 체크가 동시에 이루어질 경우 데이터가 꼬일 수 있음.
//	private static Map<String, Object> errorMap;
	public static Map<String, Object> getErrorMap(BindingResult bindingResult) {
		Map<String, Object> errorMap = new HashMap<>();

		bindingResult.getFieldErrors().forEach(error -> {
			
			String fieldName = error.getField();	
			String errorMessage = error.getDefaultMessage();
					
			// 에러명이 맵에 키값으로 존재안함?
			if (!errorMap.containsKey(fieldName)) {
				errorMap.put(fieldName, new ArrayList<>());
			}

			List<String> errorList = (List<String>) errorMap.get(fieldName);
			// 에러명으로 키값 만들어주기
			errorList.add(errorMessage);

		});
		return errorMap;

	}

//	public static Map<String, Object> getErrorMap(){
//		return errorMap;
//	}
}
