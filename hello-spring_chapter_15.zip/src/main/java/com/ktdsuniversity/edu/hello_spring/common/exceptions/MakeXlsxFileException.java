package com.ktdsuniversity.edu.hello_spring.common.exceptions;

public class MakeXlsxFileException extends RuntimeException {

	private static final long serialVersionUID = 268101011537716204L;
	
	public MakeXlsxFileException(String message) {
		super(message);
	}
}
