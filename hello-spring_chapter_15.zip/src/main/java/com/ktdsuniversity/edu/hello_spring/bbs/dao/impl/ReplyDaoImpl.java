package com.ktdsuniversity.edu.hello_spring.bbs.dao.impl;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ktdsuniversity.edu.hello_spring.bbs.dao.ReplyDao;
import com.ktdsuniversity.edu.hello_spring.bbs.vo.ModifyReplyVO;
import com.ktdsuniversity.edu.hello_spring.bbs.vo.ReplyVO;
import com.ktdsuniversity.edu.hello_spring.bbs.vo.WriteReplyVO;

@Repository
public class ReplyDaoImpl extends SqlSessionDaoSupport implements ReplyDao {

	
	@Autowired
	@Override
	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		super.setSqlSessionTemplate(sqlSessionTemplate);
	}
	
	@Override
	public int getRepliesAllCount(int boardId) {
		return getSqlSession().selectOne(NAMESPACE+"getRepliesAllCount", boardId);
	}
	
	
	@Override
	public List<ReplyVO> getAllReplies(int boardId) {
		return getSqlSession().selectList(NAMESPACE+"getAllReplies", boardId);
	}
	
	@Override
	public ReplyVO getOneReply(int replyId) {
		return getSqlSession().selectOne(NAMESPACE+"getOneReply", replyId);
	}
	
	@Override
	public int createNewReply(WriteReplyVO writeReplyVO) {
		return getSqlSession().insert(NAMESPACE+"createNewReply", writeReplyVO);
	}
	
	@Override
	public int deleteOneReply(int replyId) {
		return getSqlSession().delete(NAMESPACE+"deleteOneReply", replyId) ;
	}
	
	@Override
	public int modifyOneReply(ModifyReplyVO modifyReplyVO) {
		return getSqlSession().update(NAMESPACE+"modifyOneReply", modifyReplyVO);
	}
	
	@Override
	public int recommendOneReply(int replyId) {
		return getSqlSession().update(NAMESPACE+"recommendOneReply", replyId);
	}
	
	
	
	
}
